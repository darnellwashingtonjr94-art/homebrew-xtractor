---
name: Feature request
about: Suggest an idea or enhancement for SandB0x-Xtract0r
title: '[FEATURE] '
labels: enhancement
assignees: ''

---

**Is your feature request related to a problem? Please describe.**
A clear description of what the problem is (e.g., "I'm always frustrated when...").

**Describe the solution you'd like**
A clear description of what you want to happen.

**Describe alternatives you've considered**
Any alternative solutions or features you've considered.

**Additional context**
Add any other context, screenshots, or diagrams about the feature request here.
